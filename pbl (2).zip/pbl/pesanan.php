<?php
session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "db_sport4u";
$connection = mysqli_connect($host, $user, $password, $database);

if (!$connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id']; // Ambil user_id dari session
    $nomor_telepon = $_POST['nomor_telepon'];
    $alamat_pengiriman = $_POST['alamat_pengiriman'];
    $total_harga = $_POST['total_harga'];
    $produk = $_POST['produk'];

    // Buat pesanan_id unik
    $pesanan_id = "PSN-" . date("YmdHis") . "-" . rand(1000, 9999);

    // Simpan data ke tabel tb_pesanan
    $query_pesanan = "INSERT INTO tb_pesanan (pesanan_id, user_id, total_harga, alamat_pengiriman) 
                      VALUES ('$pesanan_id', '$user_id', '$total_harga', '$alamat_pengiriman')";

    if (mysqli_query($connection, $query_pesanan)) {
        // Simpan detail produk ke tabel tb_pesanan_detail
        foreach ($produk as $item) {
            $produk_nama = $item['nama'];
            $jumlah = $item['jumlah'];
            $harga_per_unit = $item['harga_per_unit'];
            $subtotal = $item['subtotal'];

            $query_detail = "INSERT INTO tb_pesanan_detail (pesanan_id, produk_nama, jumlah, harga_per_unit, subtotal) 
                             VALUES ('$pesanan_id', '$produk_nama', '$jumlah', '$harga_per_unit', '$subtotal')";

            mysqli_query($connection, $query_detail);
        }

        // Redirect ke halaman resi pesanan
        header("Location: resi_pesanan.php?pesanan_id=$pesanan_id");
        exit;
    } else {
        die("Error: " . mysqli_error($connection));
    }
}
?>
