<?php
// Menghubungkan ke database
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nama_lengkap = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Validasi input
    if (empty($email) || empty($username) || empty($password) || empty($nama_lengkap)) {
        die("Semua data wajib diisi!");
    }
    
    // Enkripsi password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Query untuk memasukkan data ke database (tanpa kolom telepon dan alamat)
    $query = "INSERT INTO tb_user (email, username, password, nama_lengkap) 
              VALUES ('$email', '$username', '$hashed_password', '$nama_lengkap')";
    
    if (mysqli_query($conn, $query)) {
        // Jika berhasil, redirect ke halaman login dengan pesan sukses
        echo "<script>
                alert('Registrasi berhasil! Silakan login.');
                window.location.href = 'login_user.php';
              </script>";
        exit();
    } else {
        // Jika gagal, tampilkan pesan error
        $error_message = "Registrasi gagal: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Halaman Pendaftaran</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <style>
        body {
            background-color: #f3e0c6;
        }
        .login-container {
            max-width: 400px;
            margin: auto;
            margin-top: 100px;
            padding: 20px;
            background: rgb(243, 207, 158);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .login-container h2 {
            margin-bottom: 20px;
        }
        .logo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin: 0 auto 20px auto;
            display: block;
        }
        </style>
    </head>
    <body>
        <div class="login-container">
            <h2 class="text-center">Pendaftaran Pengguna</h2>
            
            <!-- Tampilkan pesan error jika ada -->
            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <div class="form-container">
                <img src="logo.jpg" alt="Logo" class="logo">
                
                <!-- Formulir Pendaftaran -->
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan Username" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Masukkan Nama Lengkap" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Kata Sandi</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Kata Sandi" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-user-plus"></i> Daftar</button>
                </form>
                
                <p class="text-center mt-3">
                    Sudah punya akun? <a href="login_user.php" class="link-primary">Login di sini</a>
                </p>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
