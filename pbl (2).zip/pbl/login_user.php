<?php
session_start();
include 'db.php'; // Pastikan koneksi database sesuai

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $user = mysqli_real_escape_string($conn, $_POST['user']);
    $pass = mysqli_real_escape_string($conn, $_POST['pass']);
    
    // Query untuk memeriksa apakah username atau email sesuai
    $query = "SELECT * FROM tb_user WHERE username = '$user' OR email = '$user'";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        // Verifikasi password
        if (password_verify($pass, $row['password'])) {
            // Jika berhasil login, set session ID pengguna dan status login
            $_SESSION['status_login'] = true;
            $_SESSION['user_id'] = $row['user_id']; // Mengganti id_user menjadi user_id

            // Redirect ke halaman beranda
            header('Location: beranda2.php');
            exit();
        } else {
            // Jika password salah
            $error_message = 'Username atau password salah!';
        }
    } else {
        // Jika username/email tidak ditemukan
        $error_message = 'Username atau email tidak ditemukan!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f3e0c6;
        }
        .login-container {
            max-width: 400px;
            margin: auto;
            margin-top: 100px;
            padding: 20px;
            background: rgb(243, 207, 158);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .login-container h2 {
            margin-bottom: 20px;
        }
        .logo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin: 0 auto 20px auto;
            display: block;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2 class="text-center">Login</h2>
        <?php if (isset($error_message)) : ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <div class="form-container">
            <img src="logo.jpg" alt="Logo" class="logo">
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="user" class="form-label">Masukkan Username atau Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control" id="user" name="user" placeholder="Masukkan Username atau Email" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Kata Sandi</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="pass" placeholder="Masukkan Kata Sandi" required>
                    </div>
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe" />
                    <label class="form-check-label" for="rememberMe">Ingat Saya</label>
                </div>
                <button type="submit" class="btn btn-secondary w-100">
                    <i class="fas fa-sign-in-alt"></i> Masuk
                </button>
            </form>

            <p class="text-center mt-3">
                <a href="lupa_password.php" class="link-primary">Lupa Password?</a>
            </p>
            <p class="text-center">
                Belum punya akun? <a href="daftar.php" class="link-primary">Daftar Sekarang</a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
