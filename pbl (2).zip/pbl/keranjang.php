<?php
session_start();
include 'db.php'; // Pastikan koneksi ke database

// Menangani penghapusan item dari keranjang
if (isset($_GET['hapus'])) {
    $produk_id = $_GET['hapus'];
    $delete_query = "DELETE FROM tb_keranjang WHERE produk_id = '$produk_id' AND user_id = '" . $_SESSION['user_id'] . "'";
    mysqli_query($conn, $delete_query);
    unset($_SESSION['keranjang'][$produk_id]);
}

// Menangani update jumlah produk dalam keranjang
if (isset($_POST['update_qty'])) {
    $produk_id = $_POST['produk_id'];
    $qty = $_POST['qty'];
    if ($qty > 0) {
        // Update kuantitas dalam session
        $_SESSION['keranjang'][$produk_id]['qty'] = $qty;
        
        // Update kuantitas di database
        $update_query = "UPDATE tb_keranjang SET qty = '$qty' WHERE produk_id = '$produk_id' AND user_id = '" . $_SESSION['user_id'] . "'";
        mysqli_query($conn, $update_query);
    }
}

// Ambil data keranjang dari database untuk menampilkan produk dalam keranjang
$user_id = $_SESSION['user_id'];
$query = "SELECT k.*, p.produk_nama, p.produk_harga, p.produk_foto FROM tb_keranjang k
          JOIN tb_produk p ON k.produk_id = p.produk_id
          WHERE k.user_id = '$user_id'";

$result = mysqli_query($conn, $query);
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sport4u!</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<link href="bootstrap/css/bootstrap.min.css" rel=" stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<style>
        .carousel-item img {
            height: 80vh;
            object-fit: cover;
        }
        .navbar {
             position: fixed;
             top: 0;
             width: 100%;
              z-index: 1030; /* Pastikan navbar berada di atas konten lainnya */
              height: 70px; /* Tinggi navbar */
             background-color: #8d620d;/* Warna latar */
              box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

       body {
            padding-top: 70px; /* Ruang untuk menghindari navbar */
        }

    
        .bag-warning {
            background: linear-gradient(to right, #DDBF98, #DDBF98) !important;
            color: #663c06;
        }
        footer {
            background: linear-gradient(to right, #DDBF98, #DDBF98);
        }
        
         .carousel {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
        }

        .carousel-inner {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.carousel-item {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  transition: transform 0.5s ease;
}

.carousel-item.active {
  transform: translateX(0);
}

.carousel-item.next {
  transform: translateX(100%);
}

.carousel-item.prev {
  transform: translateX(-100%);
}

.carousel-control-prev,
.carousel-control-next {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  font-size: 20px;
  color: #673f0f;
  cursor: pointer;
}

.carousel-control-prev {
  left: 0;
}

.carousel-control-next {
  right: 0;
}
.kategori-produk {
    background-color: #673f0f;
}


</style>

</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container-fluid">
        <img src="logo.jpg" alt="logo" class="rounded-circle">
        <a class="navbar-brand fw-bold" href="#">Sport4U!</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto me-4">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="hubungi_kami.php">Hubungi Kami</a>
                </li>
                
            </ul>
            <form class="d-flex" action="produk.php" method="GET">
    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
    <button class="btn btn-outline-success" type="submit">Search</button>
</form>

    

            <a href="keranjang.php" title="Keranjang" class="ms-2">
                <i class="fas fa-cart-plus"></i>
            </a>
            <a href="profil_user.php" title="Profil" class="ms-2">
                <i class="fas fa-user"></i>
            </a>
        </div>
    </div>
</nav>
<div class="container mt-5">
    <h3>Keranjang Belanja</h3>
    <?php if (mysqli_num_rows($result) > 0) { ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $total = 0;
                while ($item = mysqli_fetch_assoc($result)) {
                    $subtotal = $item['produk_harga'] * $item['qty'];
                    $total += $subtotal;
                ?>
                <tr>
                    <td>
                        <?php
                        if (isset($item['produk_foto']) && file_exists('produk/' . $item['produk_foto'])) {
                            echo '<img src="produk/' . htmlspecialchars($item['produk_foto']) . '" alt="' . htmlspecialchars($item['produk_nama']) . '" width="100">';
                        } else {
                            echo "Gambar tidak tersedia";
                        }
                        ?>
                    </td>
                    <td><?php echo htmlspecialchars($item['produk_nama']); ?></td>
                    <td>Rp. <?php echo number_format($item['produk_harga']); ?></td>
                    <td>
                        <form action="keranjang.php" method="POST" style="display: inline;">
                            <input type="hidden" name="produk_id" value="<?php echo $item['produk_id']; ?>">
                            <input type="number" name="qty" value="<?php echo $item['qty']; ?>" min="1" class="form-control" style="width: 80px; display: inline-block;">
                            <button type="submit" name="update_qty" class="btn btn-primary btn-sm mt-2">Update</button>
                        </form>
                    </td>
                    <td>Rp. <?php echo number_format($subtotal); ?></td>
                    <td>
                        <a href="keranjang.php?hapus=<?php echo $item['produk_id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
                <?php } ?>
                <tr>
                    <td colspan="4" class="text-right"><strong>Total:</strong></td>
                    <td colspan="2"><strong>Rp. <?php echo number_format($total); ?></strong></td>
                </tr>
            </tbody>
        </table>
        <a href="resi.php" class="btn btn-success">Checkout</a>
        <a href="beranda2.php" class="btn btn-warning">Kembali ke Beranda</a>
    <?php } else { ?>
        <p class="text-center">Keranjang Anda kosong.</p>
    <?php } ?>
</div>
</body>
</html>
