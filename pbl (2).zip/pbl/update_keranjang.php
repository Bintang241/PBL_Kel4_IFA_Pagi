<?php
include 'db.php'; // Pastikan file koneksi database benar
session_start();

// Pastikan user login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location = 'login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id'];

// Periksa apakah form dikirimkan
if (isset($_POST['submit'])) {
    // Ambil data dari form
    $keranjang_id = isset($_POST['id']) ? intval($_POST['id']) : 0; // Pastikan ID berupa integer
    $produk_id = isset($_POST['produk_id']) ? intval($_POST['produk_id']) : 0; // Pastikan Produk ID berupa integer
    $qty = isset($_POST['qty']) ? intval($_POST['qty']) : 0; // Pastikan qty berupa integer

    // Validasi data
    if ($keranjang_id <= 0 || $produk_id <= 0 || $qty <= 0) {
        echo "<script>alert('Data tidak valid. Harap masukkan nilai yang benar.'); window.history.back();</script>";
        exit();
    }

    // Validasi apakah keranjang milik user yang login
    $query_check = "SELECT * FROM tb_keranjang WHERE keranjang_id = ? AND user_id = ?";
    $stmt_check = $conn->prepare($query_check);
    $stmt_check->bind_param("ii", $keranjang_id, $user_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows === 0) {
        echo "<script>alert('Keranjang tidak ditemukan atau tidak sesuai dengan user Anda.'); window.history.back();</script>";
        exit();
    }

    // Update kuantitas produk di keranjang
    $query_update = "UPDATE tb_keranjang SET qty = ? WHERE keranjang_id = ? AND user_id = ?";
    $stmt_update = $conn->prepare($query_update);
    $stmt_update->bind_param("iii", $qty, $keranjang_id, $user_id);

    if ($stmt_update->execute()) {
        echo "<script>alert('Keranjang berhasil diperbarui'); window.location = 'keranjang.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui keranjang: " . $stmt_update->error . "'); window.history.back();</script>";
    }

    // Tutup statement
    $stmt_check->close();
    $stmt_update->close();
} else {
    echo "<script>alert('Form tidak valid.'); window.history.back();</script>";
}
?>
