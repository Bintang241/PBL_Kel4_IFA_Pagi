<?php
include 'db.php'; // Pastikan koneksi database sudah benar
session_start();

// Pastikan user login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location = 'login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['id'])) {
    $keranjang_id = $_GET['id'];

    // Hapus produk dari keranjang
    $query = "DELETE FROM tb_keranjang WHERE keranjang_id = '$keranjang_id' AND user_id = '$user_id'";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Produk berhasil dihapus'); window.location = 'keranjang.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus produk'); window.history.back();</script>";
    }
}
?>
