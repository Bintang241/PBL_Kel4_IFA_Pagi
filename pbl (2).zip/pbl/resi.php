<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$host = "localhost";
$user = "root";
$password = "";
$database = "db_sport4u";
$connection = mysqli_connect($host, $user, $password, $database);

if (!$connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Dapatkan user_id dari session
$user_id = $_SESSION['user_id'];

// Ambil data pengguna
$query_user = "SELECT username AS nama_lengkap, telepon, alamat FROM tb_user WHERE user_id = $user_id";
$result_user = mysqli_query($connection, $query_user);

if (!$result_user) {
    die("Query Error: " . mysqli_error($connection));
}

if ($row_user = mysqli_fetch_assoc($result_user)) {
    $nama_lengkap = $row_user['nama_lengkap'];
    $nomor_telepon = $row_user['telepon'];
    $alamat_pengiriman = $row_user['alamat'];
} else {
    echo "Data pengguna tidak ditemukan.<br>";
    exit;
}

// Ambil data keranjang
$query_cart = "SELECT produk_nama, produk_harga, qty, produk_foto FROM tb_keranjang WHERE user_id = $user_id";
$result_cart = mysqli_query($connection, $query_cart);

if (!$result_cart) {
    die("Query Error: " . mysqli_error($connection));
}

$produk = [];
$total_harga = 0;

while ($row_cart = mysqli_fetch_assoc($result_cart)) {
    $produk[] = [
        "nama" => $row_cart['produk_nama'],
        "jumlah" => $row_cart['qty'],
        "harga_per_unit" => $row_cart['produk_harga'],
        "foto" => $row_cart['produk_foto'],
        "subtotal" => $row_cart['qty'] * $row_cart['produk_harga']
    ];
    $total_harga += $row_cart['qty'] * $row_cart['produk_harga'];
}

$pembayaran = ["COD"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resi Pesanan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .carousel-item img {
            height: 80vh;
            object-fit: cover;
        }

        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1050;
            height: 70px;
            background-color: #8d620d;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        body {
            padding-top: 70px;
        }

        .bag-warning {
            background: linear-gradient(to right, #DDBF98, #DDBF98) !important;
            color: #663c06;
        }

        footer {
            background: linear-gradient(to right, #DDBF98, #DDBF98);
        }

        .carousel {
            position: relative;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }

        .carousel-inner {
            position: relative;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }

        .carousel-item {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            transition: transform 0.5s ease;
        }

        .carousel-item.active {
            transform: translateX(0);
        }

        .carousel-item.next {
            transform: translateX(100%);
        }

        .carousel-item.prev {
            transform: translateX(-100%);
        }

        .carousel-control-prev,
        .carousel-control-next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: #673f0f;
            cursor: pointer;
        }

        .carousel-control-prev {
            left: 0;
        }

        .carousel-control-next {
            right: 0;
        }

        .kategori-produk {
            background-color: #673f0f;
        }

        @media (max-width: 767px) {
            .navbar {
                height: auto;
                padding: 10px 0;
                z-index: 1050;
            }

            .navbar img {
                width: 40px;
                height: 40px;
            }

            .navbar-brand {
                font-size: 1.2rem;
            }

            .navbar-toggler {
                border-color: #673f0f;
                z-index: 1060;
            }

            .carousel-item img {
                height: 60vh;
            }

            .form-control {
                width: auto;
            }

            footer {
                text-align: center;
                padding: 20px;
            }
        }

        @media (min-width: 768px) {
            .navbar-brand {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container-fluid">
        <img src="logo.jpg" alt="logo" class="rounded-circle">
        <a class="navbar-brand fw-bold" href="#">Sport4U!</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto me-4">
                <li class="nav-item">
                    <a class="nav-link active" href="beranda2.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="hubungi_kami.php">Hubungi Kami</a>
                </li>
            </ul>
            <form class="d-flex" action="produk.php" method="GET">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
            <a href="keranjang.php" title="Keranjang" class="ms-2">
                <i class="fas fa-cart-plus"></i>
            </a>
            <a href="profil_user.php" title="Profil" class="ms-2">
                <i class="fas fa-user"></i>
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <h4>Resi Pesanan</h4>

    <!-- Alamat Pengiriman -->
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">Alamat Pengiriman</h5>
            <p class="card-text">
                <?php echo htmlspecialchars($nama_lengkap); ?>, 
                <?php echo htmlspecialchars($nomor_telepon); ?><br>
                <?php echo htmlspecialchars($alamat_pengiriman); ?>
            </p>

            <!-- Form untuk mengubah alamat -->
            <form action="ubah_alamat.php" method="POST">
                <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                <textarea name="new_alamat" class="form-control" rows="3" placeholder="Masukkan alamat baru..."><?php echo htmlspecialchars($alamat_pengiriman); ?></textarea>
                <button type="submit" class="btn btn-success mt-2">Ubah Alamat</button>
            </form>
        </div>
    </div>

    <!-- Produk Dipesan -->
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">Produk Dipesan</h5>
            <table class="table">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Foto</th>
                        <th>Jumlah</th>
                        <th>Harga per Unit</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($produk as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['nama']); ?></td>
                        <td>
                            <?php 
                            $foto_path = "produk/" . htmlspecialchars($item['foto']); 
                            $foto_path_default = "produk/default.jpg";
                            ?>
                            <img src="<?php echo file_exists($foto_path) ? $foto_path : $foto_path_default; ?>" 
                                 alt="<?php echo htmlspecialchars($item['nama']); ?>" 
                                 style="width: 50px; height: 50px;">
                        </td>
                        <td><?php echo $item['jumlah']; ?></td>
                        <td>Rp <?php echo number_format($item['harga_per_unit'], 0, ',', '.'); ?></td>
                        <td>Rp <?php echo number_format($item['subtotal'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="4"><strong>Total Harga</strong></td>
                        <td><strong>Rp <?php echo number_format($total_harga, 0, ',', '.'); ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Metode Pembayaran -->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Pembayaran</h5>
            <div>
                <?php foreach ($pembayaran as $metode): ?>
                    <div>
                        <input type="radio" id="<?php echo $metode; ?>" name="payment" value="<?php echo $metode; ?>">
                        <label for="<?php echo $metode; ?>"><?php echo $metode; ?></label>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <form action="pesanan.php" method="POST">
        <input type="hidden" name="nomor_telepon" value="<?php echo htmlspecialchars($nomor_telepon); ?>">
        <input type="hidden" name="alamat_pengiriman" value="<?php echo htmlspecialchars($alamat_pengiriman); ?>">
        <input type="hidden" name="total_harga" value="<?php echo $total_harga; ?>">

        <?php foreach ($produk as $index => $item): ?>
            <input type="hidden" name="produk[<?php echo $index; ?>][nama]" value="<?php echo htmlspecialchars($item['nama']); ?>">
            <input type="hidden" name="produk[<?php echo $index; ?>][jumlah]" value="<?php echo $item['jumlah']; ?>">
            <input type="hidden" name="produk[<?php echo $index; ?>][harga_per_unit]" value="<?php echo $item['harga_per_unit']; ?>">
            <input type="hidden" name="produk[<?php echo $index; ?>][subtotal]" value="<?php echo $item['subtotal']; ?>">
        <?php endforeach; ?>

        <button type="submit" class="btn btn-success">Buat Pesanan</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>

</body>
</html>
