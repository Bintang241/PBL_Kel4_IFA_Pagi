<?php 
    session_start();
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    include 'db.php';

    // Ambil data produk berdasarkan ID
    $produk = mysqli_query($conn, "SELECT * FROM tb_produk WHERE produk_id = '".$_GET['id']."' ");
    if (mysqli_num_rows($produk) == 0) {
        echo "Produk tidak ditemukan!";
        exit;
    }
    $p = mysqli_fetch_object($produk);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Produk</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Sport4U</a>
        </div>
    </nav>

    <!-- Detail Produk -->
    <div class="section">
        <div class="container mt-5">
            <h3>Detail Produk</h3>
            <div class="row">
                <!-- Kolom untuk gambar produk -->
                <div class="col-md-4">
                    <img src="produk/<?php echo $p->produk_foto; ?>" alt="<?php echo $p->produk_nama; ?>" class="img-fluid">
                </div>
                <!-- Kolom untuk detail produk -->
                <div class="col-md-8">
                    <form action="tambah-keranjang.php" method="POST">
                        <table class="table">
                            <tr>
                                <td>Nama</td>
                                <td><?php echo $p->produk_nama; ?></td>
                            </tr>
                            <tr>
                                <td>Harga</td>
                                <td>Rp. <?php echo number_format($p->produk_harga); ?></td>
                            </tr>
                            <tr>
                                <td>Deskripsi</td>
                                <td><?php echo $p->produk_deskripsi; ?></td>
                            </tr>
                            <tr>
                                <td>Jumlah</td>
                                <td>
                                    <input type="number" name="jumlah" class="form-control" min="1" value="1" required>
                                    <input type="hidden" name="produk_id" value="<?php echo $p->produk_id; ?>">
                                </td>
                            </tr>
                        </table>
                        <button type="submit" class="btn btn-success">Tambahkan ke Keranjang</button>
                        <a href="produk.php" class="btn btn-warning">Kembali ke beranda</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
