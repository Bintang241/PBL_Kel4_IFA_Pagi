<?php
session_start();
include 'db.php'; // Pastikan koneksi database sesuai

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Periksa apakah email ada di database
    $query = "SELECT * FROM tb_user WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $token = bin2hex(random_bytes(32)); // Token unik
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token berlaku 1 jam

        // Simpan token ke database (buat tabel `password_resets` jika belum ada)
        $insertQuery = "INSERT INTO password_resets (email, token, expires_at) VALUES ('$email', '$token', '$expires')";
        mysqli_query($conn, $insertQuery);

        // Kirim email reset password
        $resetLink = "http://yourdomain.com/reset_password.php?token=$token";
        $subject = "Reset Password Anda";
        $message = "Klik tautan berikut untuk mereset password Anda: $resetLink";
        $headers = "From: no-reply@yourdomain.com";

        if (mail($email, $subject, $message, $headers)) {
            $success_message = "Email reset password telah dikirim ke $email.";
        } else {
            $error_message = "Gagal mengirim email. Coba lagi nanti.";
        }
    } else {
        $error_message = "Email tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lupa Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f3e0c6;
        }
        .login-container {
            max-width: 400px;
            margin: auto;
            margin-top: 100px;
            padding: 20px;
            background: rgb(243, 207, 158);
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .login-container h2 {
            margin-bottom: 20px;
        }
        .logo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin: 0 auto 20px auto;
            display: block;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2 class="text-center">Lupa Password</h2>
        <?php if (isset($error_message)) : ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($success_message)) : ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        <div class="form-container">
            <img src="logo.jpg" alt="Logo" class="logo">
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label">Masukkan Email Anda</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Kirim Tautan Reset</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
