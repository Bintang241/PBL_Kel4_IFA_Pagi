<?php 
session_start();
include 'db.php';

// Exception Handling: Menangani kesalahan dengan memberi tahu pengguna dan mengarahkan mereka ke halaman login
function handleException($exception)
{
    echo '<script>alert("Terjadi kesalahan, silakan coba lagi nanti.");</script>';
    echo '<script>window.location="login.php"</script>';
}

// Menetapkan fungsi handleException untuk menangani semua exception
set_exception_handler('handleException');

// Cek apakah pengguna sudah login, jika tidak, alihkan ke halaman login
if ($_SESSION['status_login'] != true) {
    echo '<script>window.location="login.php"</script>';
    exit; // Pastikan tidak ada kode yang dijalankan setelah redirect
}

// Ambil data kategori dari database
try {
    $kategori_query = mysqli_query($conn, "SELECT * FROM tb_kategori ORDER BY kategori_id DESC");

    if (!$kategori_query) {
        throw new Exception('Gagal mengambil data kategori.');
    }
} catch (Exception $e) {
    throw $e; // Mengalihkan ke handler exception global
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sport4u!</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<link href="bootstrap/css/bootstrap.min.css" rel=" stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<style>
        .carousel-item img {
            height: 80vh;
            object-fit: cover;
        }
        .navbar {
             position: fixed;
             top: 0;
             width: 100%;
              z-index: 1030; /* Pastikan navbar berada di atas konten lainnya */
              height: 70px; /* Tinggi navbar */
             background-color: #8d620d;/* Warna latar */
              box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

       body {
            padding-top: 70px; /* Ruang untuk menghindari navbar */
        }

    
        .bag-warning {
            background: linear-gradient(to right, #DDBF98, #DDBF98) !important;
            color: #663c06;
        }
        footer {
            background: linear-gradient(to right, #DDBF98, #DDBF98);
        }
        
         .carousel {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
        }

        .carousel-inner {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.carousel-item {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  transition: transform 0.5s ease;
}

.carousel-item.active {
  transform: translateX(0);
}

.carousel-item.next {
  transform: translateX(100%);
}

.carousel-item.prev {
  transform: translateX(-100%);
}

.carousel-control-prev,
.carousel-control-next {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  font-size: 20px;
  color: #673f0f;
  cursor: pointer;
}

.carousel-control-prev {
  left: 0;
}

.carousel-control-next {
  right: 0;
}
.kategori-produk {
    background-color: #673f0f;
}


</style>

</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container-fluid">
        <img src="logo.jpg" alt="logo" class="rounded-circle">
        <a class="navbar-brand fw-bold" href="#">Sport4U!</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto me-4">
                <li class="nav-item">
                    <a class="nav-link active" href="dashboard.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="data-kategori.php">Data kategori</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="data-produk.php">Data Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="keluar.php">keluar</a>
                </li>
            </ul>
            

            <a href="profil.php" title="Profil" class="ms-2">
                <i class="fas fa-user"></i>
            </a>
        </div>
    </div>
</nav>


	<!-- content -->
	<div class="section">
		<div class="container">
			<h3>Data Kategori</h3>
			<div class="box">
				<p><a href="tambah-kategori.php">Tambah Data</a></p>
				<table border="1" cellspacing="0" class="table">
					<thead>
						<tr>
							<th width="60px">No</th>
							<th>Kategori</th>
							<th width="150px">Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$no = 1;
							$kategori = mysqli_query($conn, "SELECT * FROM tb_kategori ORDER BY kategori_id DESC");
							if(mysqli_num_rows($kategori) > 0){
							while($row = mysqli_fetch_array($kategori)){
						?>
						<tr>
							<td><?php echo $no++ ?></td>
							<td><?php echo $row['kategori_name'] ?></td>
							<td>
								<a href="edit-kategori.php?id=<?php echo $row['kategori_id'] ?>">Edit</a> || <a href="proses-hapus.php?idk=<?php echo $row['kategori_id'] ?>" onclick="return confirm('Yakin ingin hapus ?')">Hapus</a>
							</td>
						</tr>
						<?php }}else{ ?>
							<tr>
								<td colspan="3">Tidak ada data</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

</body>
</html>