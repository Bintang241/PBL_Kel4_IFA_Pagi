<?php
session_start(); // Memulai sesi untuk memeriksa status login

// Pastikan pengguna sudah login dan memiliki user_id dalam session
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo "Anda harus login terlebih dahulu.";
    exit;
}

// Ambil user_id dari session
$user_id = $_SESSION['user_id'];

include 'db.php'; // Pastikan Anda sudah menghubungkan database

// Pastikan produk_id dikirimkan melalui POST
if (!isset($_POST['produk_id']) || empty($_POST['produk_id'])) {
    echo "Produk ID tidak ditemukan.";
    exit;
}

// Ambil produk_id dari POST
$produk_id = $_POST['produk_id'];

// Ambil qty, default ke 1 jika tidak ada
$qty = isset($_POST['qty']) && is_numeric($_POST['qty']) && $_POST['qty'] > 0 ? $_POST['qty'] : 1;

// Ambil data produk dari database
$produk = mysqli_query($conn, "SELECT * FROM tb_produk WHERE produk_id = '$produk_id' AND produk_status = 1");

// Periksa apakah query berhasil
if (!$produk) {
    echo "Query gagal: " . mysqli_error($conn);
    exit;
}

// Periksa apakah produk ditemukan
if (mysqli_num_rows($produk) == 0) {
    echo "Produk tidak ditemukan atau tidak aktif.";
    exit;
}

// Ambil data produk
$p = mysqli_fetch_array($produk);

// Ambil gambar produk atau gunakan gambar default
$gambar = isset($p['produk_foto']) && !empty($p['produk_foto']) ? $p['produk_foto'] : 'default.jpg';

// Ambil harga produk
$produk_harga = $p['produk_harga'];
$produk_nama = $p['produk_nama'];

// Pastikan keranjang adalah array
if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = array();
}

// Inisialisasi jumlah (quantity) yang akan dimasukkan ke dalam keranjang
$jumlah = $qty; // Menggunakan quantity yang dikirimkan oleh form

// Cek apakah produk sudah ada di keranjang
if (isset($_SESSION['keranjang'][$produk_id])) {
    // Jika produk sudah ada, update jumlahnya
    $_SESSION['keranjang'][$produk_id]['qty'] += $jumlah;
} else {
    // Jika produk belum ada, tambahkan produk baru ke keranjang
    $_SESSION['keranjang'][$produk_id] = array(
        'produk_nama' => $produk_nama,
        'produk_harga' => $produk_harga,
        'produk_foto' => $gambar,
        'qty' => $jumlah
    );
}

// Simpan ke database tb_keranjang
$insert_query = "INSERT INTO tb_keranjang (user_id, produk_id, jumlah, qty, produk_harga, produk_nama, produk_foto, date_added) 
                 VALUES ('$user_id', '$produk_id', '$jumlah', '$qty', '$produk_harga', '$produk_nama', '$gambar', NOW())";

// Eksekusi query untuk memasukkan data ke dalam tabel tb_keranjang
if (mysqli_query($conn, $insert_query)) {
    echo "<script>alert('Produk berhasil ditambahkan ke keranjang'); window.location = 'keranjang.php';</script>";
} else {
    echo "Error: " . mysqli_error($conn);
}

// Tutup koneksi
mysqli_close($conn);
?>
