<?php
session_start(); // Memulai session untuk menyimpan data login

include 'db.php'; // Menyertakan file koneksi database

if (isset($_POST['submit'])) { // Mengecek apakah form login telah disubmit
    // Sanitasi input untuk menghilangkan spasi tambahan
    $user = trim($_POST['user']);
    $pass = trim($_POST['pass']);

    try {
        // Cek jika username atau password kosong
        if (empty($user) || empty($pass)) {
            throw new Exception("Username dan password wajib diisi.");
        }

        // Persiapkan query untuk mencari username yang sesuai di database
        $stmt = $conn->prepare("SELECT * FROM tb_admin WHERE username = ?");
        $stmt->bind_param("s", $user); // Bind parameter untuk menghindari SQL injection
        $stmt->execute(); // Eksekusi query
        $result = $stmt->get_result(); // Ambil hasil query

        // Cek apakah ada user yang ditemukan
        if ($result->num_rows > 0) {
            $d = $result->fetch_object(); // Ambil data user yang ditemukan

            // Verifikasi password yang dimasukkan dengan password yang ada di database (menggunakan MD5)
            if (md5($pass) == $d->password) {
                // Jika password sesuai, set session login
                $_SESSION['status_login'] = true; // Menandakan user sudah login
                $_SESSION['a_global'] = $d; // Menyimpan data user di session
                $_SESSION['id'] = $d->admin_id; // Menyimpan ID admin

                // Redirect ke halaman dashboard setelah login berhasil
                header("Location: dashboard.php");
                exit;
            } else {
                // Jika password salah, lempar exception dengan pesan error
                throw new Exception("Password yang Anda masukkan salah.");
            }
        } else {
            // Jika username tidak ditemukan, lempar exception dengan pesan error
            throw new Exception("Username tidak ditemukan.");
        }
    } catch (Exception $e) {
        // Tangani exception dan tampilkan pesan error
        echo '<script>alert("' . $e->getMessage() . '")</script>';
    }
}
?>

<!-- HTML untuk form login -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body id="bg-login">
    <div class="box-login">
        <h2>Login</h2>
        <form action="" method="POST">
            <!-- Input untuk username -->
            <input type="text" name="user" placeholder="Username" class="input-control" required>
            <!-- Input untuk password -->
            <input type="password" name="pass" placeholder="Password" class="input-control" required>
            <!-- Tombol submit untuk login -->
            <input type="submit" name="submit" value="Login" class="btn">
        </form>
    </div>
</body>
</html>
