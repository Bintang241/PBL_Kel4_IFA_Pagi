<?php
session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "db_sport4u";
$connection = mysqli_connect($host, $user, $password, $database);

if (!$connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Dapatkan pesanan_id dari URL
$pesanan_id = $_GET['pesanan_id'];

// Ambil data pesanan
$query_pesanan = "SELECT * FROM tb_pesanan WHERE pesanan_id = '$pesanan_id'";
$result_pesanan = mysqli_query($connection, $query_pesanan);
$data_pesanan = mysqli_fetch_assoc($result_pesanan);

// Ambil detail produk dalam pesanan
$query_detail = "SELECT * FROM tb_pesanan_detail WHERE pesanan_id = '$pesanan_id'";
$result_detail = mysqli_query($connection, $query_detail);

if (!$data_pesanan) {
    die("Pesanan tidak ditemukan.");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resi Pesanan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<link href="bootstrap/css/bootstrap.min.css" rel=" stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<style>
        .carousel-item img {
            height: 80vh;
            object-fit: cover;
        }
        .navbar {
             position: fixed;
             top: 0;
             width: 100%;
              z-index: 1030; /* Pastikan navbar berada di atas konten lainnya */
              height: 70px; /* Tinggi navbar */
             background-color: #8d620d;/* Warna latar */
              box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

       body {
            padding-top: 70px; /* Ruang untuk menghindari navbar */
        }

    
        .bag-warning {
            background: linear-gradient(to right, #DDBF98, #DDBF98) !important;
            color: #663c06;
        }
        footer {
            background: linear-gradient(to right, #DDBF98, #DDBF98);
        }
        
         .carousel {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
        }

        .carousel-inner {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.carousel-item {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  transition: transform 0.5s ease;
}

.carousel-item.active {
  transform: translateX(0);
}

.carousel-item.next {
  transform: translateX(100%);
}

.carousel-item.prev {
  transform: translateX(-100%);
}

.carousel-control-prev,
.carousel-control-next {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  font-size: 20px;
  color: #673f0f;
  cursor: pointer;
}

.carousel-control-prev {
  left: 0;
}

.carousel-control-next {
  right: 0;
}
.kategori-produk {
    background-color: #673f0f;
}



</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container-fluid">
        <img src="logo.jpg" alt="logo" class="rounded-circle">
        <a class="navbar-brand fw-bold" href="#">Sport4U!</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto me-4">
                <li class="nav-item">
                    <a class="nav-link active" href="beranda2.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="hubungi_kami.php">Hubungi Kami</a>
                </li>
                
            </ul>
            <form class="d-flex" action="produk.php" method="GET">
    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
    <button class="btn btn-outline-success" type="submit">Search</button>
</form>

    

            <a href="keranjang.php" title="Keranjang" class="ms-2">
                <i class="fas fa-cart-plus"></i>
            </a>
            <a href="profil_user.php" title="Profil" class="ms-2">
                <i class="fas fa-user"></i>
            </a>
        </div>
    </div>
</nav>
    <div class="container">
        <h4>Resi Pesanan</h4>
        <p><strong>ID Pesanan:</strong> <?php echo $data_pesanan['pesanan_id']; ?></p>
        <p><strong>Total Harga:</strong> Rp <?php echo number_format($data_pesanan['total_harga'], 0, ',', '.'); ?></p>
        <p><strong>Status Pembayaran:</strong> <?php echo $data_pesanan['status_pembayaran']; ?></p>
        <p><strong>Status Pengiriman:</strong> <?php echo $data_pesanan['status_pengiriman']; ?></p>

        <h5>Detail Produk:</h5>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Jumlah</th>
                    <th>Harga per Unit</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result_detail)): ?>
                <tr>
                    <td><?php echo $row['produk_nama']; ?></td>
                    <td><?php echo $row['jumlah']; ?></td>
                    <td>Rp <?php echo number_format($row['harga_per_unit'], 0, ',', '.'); ?></td>
                    <td>Rp <?php echo number_format($row['subtotal'], 0, ',', '.'); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
