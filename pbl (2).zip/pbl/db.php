<?php
$host = 'localhost';  // Database host
$user = 'root';       // Database username
$pass = '';           // Database password (use your actual password)
$dbname = 'db_sport4u';  // Database name

// Create connection
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
