<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$host = "localhost";
$user = "root";
$password = "";
$database = "db_sport4u";
$connection = mysqli_connect($host, $user, $password, $database);

if (!$connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Dapatkan user_id dari session
$user_id = $_SESSION['user_id'];

// Ambil data pengguna
$query_user = "SELECT username, telepon, alamat FROM tb_user WHERE user_id = $user_id";
$result_user = mysqli_query($connection, $query_user);

if (!$result_user) {
    die("Query Error: " . mysqli_error($connection));
}

$row_user = mysqli_fetch_assoc($result_user);
$nama_lengkap = $row_user['username'];
$nomor_telepon = $row_user['telepon'];
$alamat_pengiriman = $row_user['alamat'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $alamat_baru = $_POST['alamat_baru'];

    // Update alamat di database
    $query_update = "UPDATE tb_user SET alamat = '$alamat_baru' WHERE user_id = $user_id";
    if (mysqli_query($connection, $query_update)) {
        // Menyimpan alamat baru di session
        $_SESSION['alamat_pengiriman'] = $alamat_baru;
        echo "<script>alert('Alamat berhasil diperbarui.'); window.location.href = 'resi_pesanan.php';</script>";
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Alamat</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Sport4U</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="profil_user.php">Profil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="keranjang.php">Keranjang</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5 pt-5">
    <h4>Ubah Alamat Pengiriman</h4>
    
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title">Alamat Pengiriman Saat Ini</h5>
            <p class="card-text">
                <?php echo htmlspecialchars($nama_lengkap); ?>, <br>
                <?php echo htmlspecialchars($nomor_telepon); ?><br>
                <?php echo htmlspecialchars($alamat_pengiriman); ?>
            </p>
        </div>
    </div>
    
    <form action="ubah_alamat.php" method="POST">
        <div class="mb-3">
            <label for="alamat_baru" class="form-label">Alamat Baru</label>
            <textarea class="form-control" id="alamat_baru" name="alamat_baru" rows="3" required><?php echo htmlspecialchars($alamat_pengiriman); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Alamat Baru</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
